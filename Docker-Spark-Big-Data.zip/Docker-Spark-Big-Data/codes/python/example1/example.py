# -*- coding: utf-8 -*-

from pyspark.sql import SparkSession

# Khởi tạo một SparkSession
spark = SparkSession.builder \
    .appName("Simple Spark Program") \
    .getOrCreate()

# Tạo một DataFrame từ một danh sách Python
data = [("John", 25), ("Bob", 30), ("Alice", 35)]
df = spark.createDataFrame(data, ["Name", "Age"])

# Hiển thị DataFrame
df.show()

# Đóng SparkSession
spark.stop()
