# -*- coding: utf-8 -*-
import os
import sys
from pyspark.sql import SparkSession
from pyspark.sql.functions import col, from_json
from pyspark.sql.types import StringType, StructType, StructField
import pyspark.sql.functions as F
import pyspark.sql.types as T

# Kiểm tra phiên bản Python
print("Python version")
print(sys.version)
print("Version info.")
print(sys.version_info)

# Thiết lập biến môi trường
KAFKA_SERVER = os.getenv('KAFKA_SERVER', 'localhost:9092')
KAFKA_TOPIC = os.getenv('KAFKA_TOPIC', 'data')
MONGO_URI = os.getenv('MONGO_URI', 'mongodb://localhost:27017/batdongsan.collection')

# Khai báo schema cho dữ liệu bất động sản
data_schema = StructType([
    StructField("Loại", StringType(), True),
    StructField("Tỉnh", StringType(), True),
    StructField("Khu vực", StringType(), True),
    StructField("Giá tiền", StringType(), True),
    StructField("Diện tích", StringType(), True)
])

@F.udf(returnType=T.StringType())
def format_data_Dien_Tich(data_DienTich):
    data_DienTich = str(data_DienTich)
    numbers = [int(s) for s in data_DienTich.split() if s.isdigit()]
    if not numbers:
        return "not found"
    return str(numbers[0])

@F.udf(returnType=T.StringType())
def format_data_Gia(data_Gia):
    data_Gia = str(data_Gia)
    try:
        data_Gia = data_Gia.strip().lower()
        if "triệu" in data_Gia:
            gia = float(data_Gia.split()[0]) * 1000000
            return str(int(gia))
        elif "tỷ" in data_Gia:
            gia = float(data_Gia.split()[0]) * 1000000000
            return str(int(gia))
        else:
            return "not-found"
    except ValueError:
        return "not-found"

@F.udf(returnType=T.StringType())
def format_data_Khu_Vuc(data_Khu_Vuc):
    data_Khu_Vuc = str(data_Khu_Vuc)
    try:
        return data_Khu_Vuc.upper()
    except ValueError:
        return "not-found"

@F.udf(returnType=T.StringType())
def format_data_loai(data_loai):
    data_loai = str(data_loai)
    try:
        return data_loai.upper()
    except ValueError:
        return "not-found"

@F.udf(returnType=T.StringType())
def format_data_tinh(data_tinh):
    data_tinh = str(data_tinh)
    try:
        return data_tinh.upper()
    except ValueError:
        return "not-found"

def write_to_mongodb(df, epoch_id):
    df.write.format("com.mongodb.spark.sql.DefaultSource") \
        .mode("append") \
        .option("replaceDocument", "false") \
        .option("upsert", "true") \
        .option("database", "data-analysis") \
        .option("collection", "batdongsan") \
        .save()

def transform_and_ingest():
    spark = SparkSession.builder \
        .appName("batdongsan") \
        .config("spark.executor.heartbeatInterval", "10000ms") \
        .config("spark.mongodb.input.uri", MONGO_URI) \
        .config("spark.mongodb.output.uri", MONGO_URI) \
        .config("spark.cores.max", "2") \
        .config("spark.executor.memory", "2g") \
        .getOrCreate()

    data_df = spark \
        .readStream \
        .format("kafka") \
        .option("kafka.bootstrap.servers", KAFKA_SERVER) \
        .option("subscribe", KAFKA_TOPIC) \
        .option("startingOffsets", "latest") \
        .option("failOnDataLoss", "false") \
        .load()

    data_df = data_df.selectExpr("CAST(value AS STRING)") \
        .select(from_json("value", data_schema).alias('data'))
    data_df = data_df.select('data.*')

    data_df = data_df.withColumn("Loại", format_data_loai(col("Loại")))
    data_df = data_df.withColumn("Tỉnh", format_data_tinh(col("Tỉnh")))
    data_df = data_df.withColumn("Khu vực", format_data_Khu_Vuc(col("Khu vực")))
    data_df = data_df.withColumn("Giá tiền", format_data_Gia(col("Giá tiền")))
    data_df = data_df.withColumn("Diện tích", format_data_Dien_Tich(col("Diện tích")))

    query = data_df.writeStream \
        .outputMode("append") \
        .foreachBatch(write_to_mongodb) \
        .start()

    query.awaitTermination()

if __name__ == "__main__":
    transform_and_ingest()
